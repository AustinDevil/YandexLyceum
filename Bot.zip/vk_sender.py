import vk
import random


def send_message(id, text):
    session = vk.Session(access_token='03210bbf44289cee1fffdf7fcf8ebe2a0ca2d4f8e166bca99b13e411f4411bc193cf99d0a7e604cfa85f2')
    vka = vk.API(session, v=5.8)
    token = '03210bbf44289cee1fffdf7fcf8ebe2a0ca2d4f8e166bca99b13e411f4411bc193cf99d0a7e604cfa85f2'

    if type(id) == int:
        vka.messages.send(user_id=id, message=text, random_id=random.randint(0, 2 ** 64), access_token=token)
    else:
        name = vka.users.get(access_token=token, user_ids=id)
        vka.messages.send(user_id=name[0]['id'], message=text)