import asyncio
import vk_api
import discord
import random
import sqlite3
import vk_sender
from discord.ext import commands


class Just_a_discord_bot(discord.Client):
    def __init__(self):
        super().__init__()
        self.address = None
        self.msg_triggered = False
        self.new_contact = False
        self.msg_text = None
        self.curent_usr = None
        self.db = sqlite3.connect("data.sqlite")
        self.cursor = self.db.cursor()

    async def on_ready(self):
        print(f'{self.user} has connected to Discord!')
        for guild in self.guilds:
            print(
                f'{self.user} подключились к чату:\n'
                f'{guild.name}(id: {guild.id})')

    async def on_member_join(self, member):
        await member.create_dm()
        await member.dm_channel.send(
            f'Привет, {member.name}!')

    async def on_message(self, message):
        if message.author == self.user:
            return
        elif message.content == "dtv сообщение":
            await message.channel.send("кому пишем?")
            self.msg_triggered = not self.msg_triggered
        elif message.content == 'dtv стоп':
            await message.channel.send("принял")
            self.stop()
        elif 'vk.com/' in message.content and not self.new_contact:
            await message.channel.send("и что мы ему напишем?")
            self.address = message.content
            self.msg_triggered = not self.msg_triggered
        elif self.address is not None:
            self.msg_text = message.content
            print(''.join(self.address[6::]))
            vk_sender.send_message(''.join(self.address[7::]), self.msg_text)
            await message.channel.send("отправляю пользователю " + self.address + " сообщение *" + self.msg_text + "*")
        elif message.content == "dtv запиши контакт":
            await message.channel.send("напишите контакт в формате: *имя контакта* *ссылка на контакт*")
            self.new_contact = True
        elif self.new_contact:
            c = message.content.split()
            self.cursor.execute("INSERT INTO call_book VALUES (1 , '" + c[0] + "','" + c[1]+"')")
            self.db.commit()
            self.new_contact = False


    def stop(self):
        self.address = None
        self.msg_triggered = False
        self.msg_text = None
        self.curent_usr = None


client = Just_a_discord_bot()
client.run("NzA1NDQ4MjY0NjQ4MDk3ODYz.Xqr4QQ.akz3VXsU86VnYqQuPD_mXLGU9Ag")
